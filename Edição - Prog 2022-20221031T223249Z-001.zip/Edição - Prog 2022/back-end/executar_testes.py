from geral.config import *
import import_modelos
from testes import *

TestarPessoa.run()
